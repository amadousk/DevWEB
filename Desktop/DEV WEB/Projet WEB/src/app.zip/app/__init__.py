from flask import Flask, render_template
from flask_sqlalchemy import SQLAlchemy
import os

app = Flask(__name__)
app.config['SQLACHEMY_DATABASE_URI'] = os.environ['DATABSE_URL']
db = SQLAlchemy(app)
db.init_app(app)

class Data(db.Model) :
    __tabname = "data"

    id              = db.Column(db.Integer, primary_key=True)
    id_rna          = db.Column(db.Varchar(30), nullable=True)
    rna_id_ex_id    = db.Column(db.Varchar(30), nullable=True)
    gestion         = db.Column(db.Varchar(30), nullable=True)

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/hello')
@app.route('/hello/<name>')
def hello(name=None):
    return render_template('hello.html', name=name)

if __name__ == '__main__':
    app.run()